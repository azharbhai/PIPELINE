# Simple Examples

This folder contains simple Declarative Pipelines with one or two stages.
The pipelines in this folder are examples of specific features or useful in testing.

The naming convention is based on the primary feature being exhibited.
