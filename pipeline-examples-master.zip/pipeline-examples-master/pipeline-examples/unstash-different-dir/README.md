# Synopsis

This is a simple demonstration of how to unstash to a different
directory than the root directory, so that you can make sure not to
overwrite directories or files, etc.

